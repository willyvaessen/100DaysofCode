# 28 August 2023

No files in this directory. I've been working on the [JavaScript.info](https://javascript.info/) 
tutorial, as a refresher to my JavaScript knowledge. 

I will post my updates to
the corresponding [repository](https://github.com/willyvaessen/willy.javascript.info).