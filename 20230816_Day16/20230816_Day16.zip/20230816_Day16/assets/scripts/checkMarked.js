if (typeof marked !== 'undefined') {
  // marked library is available
  console.log('marked library is available');
  // You can use the marked library here
} else {
  // marked library is not available
  console.log('marked library is not available');
  // You might want to load the library here
}
