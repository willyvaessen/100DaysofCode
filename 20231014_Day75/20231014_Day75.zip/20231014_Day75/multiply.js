import * as readline from "readline";

console.log("Practice multiplying");
let userInput = readline("Enter your answer: ");
console.log(userInput);
let left = Math.floor((Math.random() * 10)+1);
let right = Math.floor((Math.random() * 10)+1);
console.log(left);
console.log(right);
